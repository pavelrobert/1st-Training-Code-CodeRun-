from django.apps import AppConfig


class Demo1Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'demo1'
