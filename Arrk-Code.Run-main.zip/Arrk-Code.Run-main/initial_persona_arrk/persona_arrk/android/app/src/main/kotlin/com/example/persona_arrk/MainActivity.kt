package com.example.persona_arrk

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
