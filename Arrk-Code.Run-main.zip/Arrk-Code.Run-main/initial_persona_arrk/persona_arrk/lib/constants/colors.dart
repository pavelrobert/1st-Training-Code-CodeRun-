import 'package:flutter/material.dart';

const kGreyColor = Color.fromRGBO(63, 71, 86, 1);
const kBlueColor = Color.fromRGBO(42,85,252, 1);
const kPurpleColor = Color.fromRGBO(209,42,252, 1);
const kYellowColor = Color.fromRGBO(252,209,42, 1);
const kRedColor = Color.fromRGBO(252,42,85, 1);
const kGreenColor = Color.fromRGBO(42,252,209, 1);
const kWhiteColor = Color.fromRGBO(255,254,244, 1);
const kBlackColor = Color.fromRGBO(43,39,48, 1);