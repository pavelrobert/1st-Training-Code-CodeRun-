import 'package:flutter/material.dart';

const kAppTitle = 'Persona App Arrk';